import pickle
import os
import numpy as np

MODEL_DIR = os.path.join(os.path.dirname(__file__), 'models')

def extract_features(vin):
    vin = vin.upper()
    vin_length = len(vin)
    digit_count = sum(c.isdigit() for c in vin)
    letter_count = sum(c.isalpha() for c in vin)
    has_invalid_chars = int(any(c in 'IOQ' for c in vin))
    return np.array([[vin_length, digit_count, letter_count, has_invalid_chars]])

def load_model(name):
    path = os.path.join(MODEL_DIR, f"{name}.pkl")
    with open(path, "rb") as f:
        return pickle.load(f)

def predict_all_models(vin):
    x = extract_features(vin)
    results = {}
    for model_name in ["naive_bayes", "decision_tree", "svm", "logistic_regression", "random_forest", "knn"]:
        model = load_model(model_name)
        pred = model.predict(x)[0]
        prob = model.predict_proba(x)[0][1] if hasattr(model, 'predict_proba') else None
        results[model_name] = {
            "prediction": int(pred),
            "confidence": round(float(prob), 2) if prob is not None else "N/A"
        }

    kmeans = load_model("kmeans")
    cluster = int(kmeans.predict(x)[0])
    results["kmeans"] = {"cluster": cluster}

    return results
