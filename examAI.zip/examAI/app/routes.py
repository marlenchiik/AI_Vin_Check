from flask import Blueprint, render_template, request
from app.vin_ai_utils import predict_all_models
import re

main = Blueprint('main', __name__)

def is_valid_vin(vin):
    return bool(re.fullmatch(r'^[A-HJ-NPR-Z0-9]{17}$', vin.upper()))

@main.route('/', methods=['GET', 'POST'])
def index():
    vin = ''
    result_dict = {}
    base_message = None

    if request.method == 'POST':
        vin = request.form.get('vin', '')
        if is_valid_vin(vin):
            result_dict = predict_all_models(vin)
            base_message = f"✅ VIN {vin} выглядит корректным"
        else:
            base_message = f"❌ VIN {vin} — некорректный формат"

    return render_template('index.html', vin=vin, result_dict=result_dict, base_message=base_message)
